﻿#include "InteractiveNavigationSettings.h"

#include "InteractiveNavigationUtils.h"
#include "NavigationWidgets/SNavigationManagerWidget.h"

#define LOCTEXT_NAMESPACE "InteractiveViewportNavigation"

UInteractiveNavigationSettings::UInteractiveNavigationSettings()
{
	bManualCorrectDeviation = false;
	DPI = EDisplayDeviceScaling::DPI_100;
}

FName UInteractiveNavigationSettings::GetCategoryName() const
{
	return TEXT("Plugins");
}

#if WITH_EDITOR
FText UInteractiveNavigationSettings::GetSectionText() const
{
	return LOCTEXT("InteractiveViewportNavigationSettings", "Interactive Viewport Navigation");
}

FName UInteractiveNavigationSettings::GetSectionName() const
{
	return TEXT("Interactive Viewport Navigation");
}

FText UInteractiveNavigationSettings::GetSectionDescription() const
{
	return FText::FromString(TEXT("The DPI of the first display device is obtained by default to calibrate the position of the mouse and navigation. \nWhen automatic calibration fails, it can be set manually here."));
}

void UInteractiveNavigationSettings::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	Super::PostEditChangeProperty(PropertyChangedEvent);

	SNavigationManagerWidget::UpdateDPIScaling(this);
}
#endif

#undef LOCTEXT_NAMESPACE